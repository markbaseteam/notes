---
type : 
subject : 
type : Concept
subject : Chemistry
date created: Friday, May 20th 2022, 2:59:12 pm
date modified: Friday, May 20th 2022, 3:06:36 pm
title: Carbocation
---
[[General Organic Chemistry MOC]]
# Carbocation

1. Kabhi bhi Carbocation ke bagal mein lone pair wale group hain voh structure stable nahi Bahut Bahut Stable hota hain (Because of a High Quality Resonance
2. Carbacation ko pasand hain $+I$ and $+M$ ^ba2aa2