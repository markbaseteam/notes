1. Comparison of  Enol Content
	1. ![](https://i.imgur.com/qGUsvNB.png)
	>Option 3 is a form of Beta Di-Ketone(Aldehyde Form) so it has the Highest Enol Content

2. Compounds that Show G.I
	1. ![](https://i.imgur.com/mmurdfS.png)
	> (E) mein nahi hogi kyonki Cycloalkene mein 8 se kam Carbon Chain mein koi GI nahi hoti.
	> (F) mein nahi hogi kyonki pi bond ke bagal mein koi khali jagah hain he nahi do compounds ko exists karne ke liye.