# Tautomerism
0. Ek molecule, solution ke andar two different isomers mein exisit karta hain
1. It can never take place in Solid. It requires solution to take place.
2. When Aldehyde Ketone has an acidic aalpha CH3 so it attaches itself to O to form enol.
3. It exisits in Dynamic Equilibrium
4. They are converting into each other.
5. Ek Doosre mein Yeh Dono Isomers Convert Hote hain
6. >![](https://i.imgur.com/8DPogrb.png)
7. Hum Us Carbon ke Hydrogen ko Lete Jis Taraf Carbon ki Sankhya Kum Ho.
>![](https://i.imgur.com/8hZ8hTN.png)
>Double Bond  Jis C pe usi pe hain OH


## Condition for Tautomerism
1. Carbonyl Group that is jahan pe Polar Pi Bond hein (Multab do Different Electronegaitve Atoms ke Beech mein Bond)
2. Presence of Alpha Hydrogen
	1. ![](https://i.imgur.com/dDoQWFK.png)
	2. Double Bond Wale Carbon Ka Hydrogen Tautomerism mein Participate Nahi Karta hain
	>![](https://i.imgur.com/FW1fbW6.png)
	3. Participation of $\gamma$ Hydrogen in Tautomerism
	>![](https://i.imgur.com/MQHjBhG.png)

## Percentage of Keto & Enol Form
1. Keto Dominates with 99% Concentration and Enol is Hardly 2%
2. Becuase of the Strong C=O bond that Hulka Fulka Resonance in C=C Bond.
3. C=o majboot hain, kyonki oygen chota hain, aur badhiya bond banata hain

### Factors Affecting Enol Content in Molecule
1. Acidic Strength
2. Extendend Resonance
3. Intermolecular H bond
4. Aromaticity (Highest Wighing Factor)
>![](https://i.imgur.com/31pUVxe.png)

### Examples of Abnormal Concentrations
1. Beta Keto Ester (15% Enol- 85% Keto)
	1. Isme Intramolecular H bonding bhi hoti hain
	2. Resonance Structure Bhi Bada Hota hain
	>![](https://i.imgur.com/0OmAhgl.png)
2. Series of Abnormal Enol Content
	1. Aldehyde Ketone 2% Enol
	2. Beta Keto Ester 15%
	3. Beta Di-Ketone 75%
	4. Phenol 100%
>![](https://i.imgur.com/0ZMpYVD.png)


## Difference Between Tautomerism and Resonance
1. Resonance is a Hypothetical Phenomenon While Tautomerism is a Real Phenomenon.
2. Tautomerism there is a Movement of an Electron, In Resonancne there is no movement of the electron
3. Tautomers are in Dynamic Equilibrium while iN Resonance Only One COmpound Exists.
4. 