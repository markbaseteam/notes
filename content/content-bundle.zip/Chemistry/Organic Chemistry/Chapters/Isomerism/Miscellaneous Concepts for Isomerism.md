[[Isomerism MOC]]
1. ![](https://i.imgur.com/KMCbqxO.png) #revise-before-exam 
> Option A is given in the Enol Form.