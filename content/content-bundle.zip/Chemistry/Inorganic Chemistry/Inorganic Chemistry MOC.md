---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Saturday, May 28th 2022, 11:51:01 am
date modified: Monday, May 30th 2022, 11:56:07 pm
title: Inorganic Chemistry MOC
---
[[Chemistry MOC]]

# Inorganic Chemistry MOC
+ Mentor : Amitabh Sir
## 1. Co-ordination Compounds
1. [[Co-ordination Compounds MOC|Co-ordination Compounds]]
2. [[Question Bag for Co-ordination Compounds|Question Bag]]
3. [[Compiled Concepts for Co-ordination Compounds|Compiled Concepts]]
