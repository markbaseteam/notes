---
type : 
subject : 
branch :
chapter :
type : Concept
subject : Chemistry
branch : Physical
chapter : Chemical Kinetics
date created: Saturday, May 21st 2022, 5:26:28 pm
date modified: Saturday, May 21st 2022, 5:27:04 pm
title: Chemical Reactions
---
[[Chemical Kinetics MOC]]

# Chemical Reactions
>[!lecpg] Lecture Slide for Chemical Reactions
>![](https://i.imgur.com/5umSlOd.png)
