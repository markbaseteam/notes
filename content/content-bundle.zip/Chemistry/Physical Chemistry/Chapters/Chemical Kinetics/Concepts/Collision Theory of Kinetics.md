---
type : 
subject : 
branch :
chapter :
type : Concept
subject : Chemistry
branch : Physical Chemistry
chapter : Chemical Kinetics
date created: Sunday, May 22nd 2022, 11:04:09 am
date modified: Sunday, May 22nd 2022, 11:04:54 am
title: Collision Theory of Kinetics
---

[[Chemical Kinetics MOC]]

# Collision Theory of Kinetics
1. The reactant molecules must collide for the reaction to take place.
2. The molecular must collide with the maximum energy known as the threshold energy
3. 