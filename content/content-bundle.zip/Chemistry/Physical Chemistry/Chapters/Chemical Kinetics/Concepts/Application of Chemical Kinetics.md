---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Sunday, May 22nd 2022, 10:16:19 am
date modified: Sunday, May 22nd 2022, 10:16:53 am
title: Application of Chemical Kinetics
---

[[Chemical Kinetics MOC]]

# Application of Chemical Kinetics
## Pressure Relation to Concentration
1. Pressure is directly proportional to Concentration
>[!conc] Concept
>![](https://i.imgur.com/8BZDkSO.png)


2. Equation of Pressure Relation
>[!visill] Visual Illustration
>![](https://i.imgur.com/1LKXyoO.png)
