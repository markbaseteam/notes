---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Saturday, May 21st 2022, 1:16:12 pm
date modified: Saturday, May 21st 2022, 1:17:03 pm
title: Rate of Chemical Kinetics
---
[[Chemical Kinetics MOC]]

# Rate of Chemical Kinetics
## Rate of Chemical Reactions
>[!lecpg] Lecture Slide for Rate of Chemical Reactions
>![](https://i.imgur.com/Kzunz5X.png)
>1. ![](https://i.imgur.com/PfZ2BrA.png)
>2. ![](https://i.imgur.com/uZVOSqk.png)
>3. ![](https://i.imgur.com/ru0VM1g.png)
