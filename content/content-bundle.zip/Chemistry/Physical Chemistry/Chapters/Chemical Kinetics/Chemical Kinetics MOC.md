---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Saturday, May 21st 2022, 1:01:09 pm
date modified: Saturday, May 21st 2022, 1:02:14 pm
title: 0.0.0.0.0.1 Chemical Kinetics MOC
---
[[Physical Chemistry MOC]]

# 0.0.0.0.0.1 Chemical Kinetics
Chemical Kinetics is all about Speed of the Reaction that is Kinetics


## 1. [[Chemical Reactions]]
## 2. [[Rate of Chemical Kinetics]]

## 3. [[Factors affecting rate of Reaction]]
## 4. [[Application of Chemical Kinetics]]
## 5. [[Question Bag for Chemical Kinetics|Question Bag]]

## 6. [[Collision Theory of Kinetics]]

