---
type : 
subject : 
branch :
chapter :
date created: Saturday, May 21st 2022, 8:38:27 pm
date modified: Tuesday, May 24th 2022, 11:22:56 am
title: Solution
---
[[Mole Concept MOC]]

# Solution

## Components of Solution

>![](https://i.imgur.com/25Et0fZ.png)
1. Mixing of Solutions
2. Dilution of Solutions

### Solute

### Solvent

## Concentration Terms

### Molarity

>![](https://i.imgur.com/KI3iqz3.png)

### Molality

>![](https://i.imgur.com/n98JKGZ.png)

### Normality

>$$N=\frac{Eq}{V}$$
>=normality![{Eq}](https://www.gstatic.com/education/formulas2/443397389/en/normality_formula_normality_formula_var_2.svg)=number of gram equivalents of solute![{V}](https://www.gstatic.com/education/formulas2/443397389/en/normality_formula_normality_formula_var_3.svg)=[volume of solvent in liters](https://www.google.com/search?sxsrf=ALiCzsbO6uYPxw6gyGIZ9mLTL5zqDSBD_Q:1652735510313&q=Titer&stick=H4sIAAAAAAAAAOPgE-LSz9U3SM8wN7IsVuIEsU2NkpIstLSyk630U1NKkxNLMvPz9NPyi3JLcxKtoLRCZm5ieqpCYl5xeWrRI0YTboGXP-4JS2lPWnPyGqMqF1dwRn65a15JZkmlkDgXG5TFK8XNhbCBZxEra0hmSWoRACcFXkyEAAAA&sa=X&ved=2ahUKEwjmt__H9-T3AhURheYKHYetCvUQ24YFegQILhAC)

### Mass/Volume%

>![](https://i.imgur.com/8JRt2WP.png)

### Mass/Mass%

>![](https://i.imgur.com/d2S8YCj.png)

### Volume/Volume%

>![](https://i.imgur.com/PNo0GdL.png)

### Mole Fraction

>![](https://i.imgur.com/kcBc9Jt.png)

### Parts Per Million $(PPM)$

>![](https://i.imgur.com/1A333aH.png)

## Conversion of Concentration Terms

>![](https://i.imgur.com/pDhz0se.png)
#important

## Limiting Reagent

Which limits the Reaction from Moving Forward.
