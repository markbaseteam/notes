---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Saturday, May 21st 2022, 8:38:27 pm
date modified: Tuesday, May 24th 2022, 11:22:30 am
title: Mole
---
[[Mole Concept MOC]]

# Mole

>![](https://i.imgur.com/bLsWcOI.png)

## Avogadro Number

>![](https://i.imgur.com/3RDNpN6.png)

## Mass

### Atomic Mass

>![](https://i.imgur.com/ASLXjZA.png)

### Molecular Mass

>![](https://i.imgur.com/ScTu6MQ.png)

### Molar Mass

>![](https://i.imgur.com/s4LvcLD.png)

## Calculation

1. No. of moles of a Species
>![](https://i.imgur.com/Wn8fMni.png)
2. No. of atoms
>![](https://i.imgur.com/hkqkznT.png)

## Volume

### Molar Volume

![](https://i.imgur.com/Eg9UXvb.png)
1. It follows [[Ideal Gas Equation]]
