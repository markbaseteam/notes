[[Physical Chemistry MOC]]
# Atomic Structure
>![](https://i.imgur.com/CTmwvMa.png)

## Sub-Atomic Particles
### Electrons
1. Mass of Electrons
	>![](https://i.imgur.com/a3brgvT.png)

2. Charge on Electrons
	>![](https://i.imgur.com/FYxb0kX.png)

### Protons

### Neutrons

