[[Surface Chemistry MOC|Back]]
# Absorption
1. ![](https://i.imgur.com/d3pOfLh.png)
