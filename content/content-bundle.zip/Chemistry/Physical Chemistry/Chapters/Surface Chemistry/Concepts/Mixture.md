[[Surface Chemistry MOC]]
# Mixture
## 1. Homogeneous Mixture
1. Uniform
2. True Solution
3. Can not be seen by Naked Eyes
4. $Particle Size \lt 1nm$
## 2. Heterogeneous Mixture
### 1. [[Colloid]]
### 2. Suspension
1. $Particle Size \gt 1000nm$
2. Can be seen by Eyes