[[Surface Chemistry MOC]]
# Miscellaneous Concepts
1. Sorption
__Absorption + Adsorption = Sorption__