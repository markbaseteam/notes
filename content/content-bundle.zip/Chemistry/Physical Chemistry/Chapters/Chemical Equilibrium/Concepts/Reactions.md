# Reactions
>![](https://i.imgur.com/gFyl4ZY.png)

## Reversible Reactions
1. >![](https://i.imgur.com/sHr8vho.png)
2. >![](https://i.imgur.com/Xh2wR2K.png)

## Irreversible Reactions
1. These reactions do not exists in nature
2. 

## Degree of Advancement

It is also called Degree of Dissociation or Extent of a Reaction
1. ![](https://i.imgur.com/32GiW7I.png)
2. ![](https://i.imgur.com/AvhyqB9.png)



### $K_p$ Calculation
We use Dalton's Law of Partial Pressure to Calculate K_p after fetching values of Mole Fraction of different Substances.
>[!note]- Application of $\alpha$
>![](https://i.imgur.com/RRLuhqw.png)
