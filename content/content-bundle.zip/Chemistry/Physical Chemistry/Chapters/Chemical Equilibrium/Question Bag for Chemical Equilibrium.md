---
number headings: auto, first-level 1, max 6, _.1.A.
type : 
subject : 
branch :
chapter :
date created: Saturday, May 21st 2022, 8:38:27 pm
date modified: Friday, May 27th 2022, 3:04:59 pm
title: Question Bag
---
[[Chemical Equilibrium MOC]]

# Question Bag

## 1. Recognize $\Delta ng$ in the Question

1. As Value of $K_p$ is given and its unit is $(atm)^{\Delta ng}$ then we may derive $\Delta ng$ even when it is not visible.
	>[!note]- Q/A Slide
	> ![](https://i.imgur.com/Ykgn0l0.png)

## 2. Concept

1. When we change Concentration of reactants it implies change in concentration of products.
2.
3.
