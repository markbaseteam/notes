# Graham's Law of Effusion
## Difference Between Diffusion and Effusion
![](https://i.imgur.com/gVYDwkM.png)

### Graham's Law of Effusion
1. >![](https://i.imgur.com/VL4y8XB.png)
2. It is a Relative Quantity

### Cases of Graham's Law
#### Case 1 : Two Different Gases in two different containers
>![](https://i.imgur.com/qjH8bvt.png)

#### Case 2 : Two Gases in same container
>![](https://i.imgur.com/NeDRKda.png)

#### Case 3 : One gas in a container and a mixture of gases in another container
>![](https://i.imgur.com/7cD0QF5.png)
