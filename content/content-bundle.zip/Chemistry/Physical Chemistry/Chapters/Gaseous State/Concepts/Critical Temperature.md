# Critical Temperature
The temperature of a gas in its critical state, above which it cannot be liquefied by pressure alone