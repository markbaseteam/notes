---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Monday, May 30th 2022, 4:49:15 pm
date modified: Friday, June 3rd 2022, 9:31:40 am
title: Chemistry Concepts
---

# Chemistry Concepts

## 1. Radicals

![[Alkanes#^yv53ff]]
