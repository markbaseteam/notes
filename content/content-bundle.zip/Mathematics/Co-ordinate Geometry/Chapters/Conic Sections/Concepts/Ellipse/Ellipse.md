[[Conics]]
# Ellipse
>[!note]- Alternative Definition of Ellipse
>![](https://i.imgur.com/OEXD7NX.png)
>![](https://i.imgur.com/Mz42P6D.png)

## 1. [[Equations of Ellipse#Standard Equation of Ellipse|Standard Equation of Ellipse]]
## 2. Terminologies
1. ![](https://i.imgur.com/CLbvmwm.png)
2. ![](https://i.imgur.com/WykJCfq.png)
3. ![](https://i.imgur.com/le87h5u.png)
4. ![](https://i.imgur.com/ZNTyZi7.png)
5. ![](https://i.imgur.com/jZKiA3o.png)
6. ![](https://i.imgur.com/ZbRNV1u.png)
7. ![](https://i.imgur.com/l3BEe17.png)

## 3. Vertical Ellipse
>![](https://i.imgur.com/a35dh9T.png)

## 4. Tangent and Normal of Ellipse
>![](https://i.imgur.com/NirVepO.png)

>![](https://i.imgur.com/JZGteBv.png)

>![](https://i.imgur.com/4Zj72qR.png)
