[[Ellipse]]
# Equations of Ellipse
## Standard Equation of Ellipse
>![](https://i.imgur.com/pufgXHJ.png)
1. Equation of Standard Ellipse
>$$S\equiv \frac{x^2}{a^2}+\frac{y^2}{b^2}=1$$

## Equations Reducible to Standard Ellipse
>![](https://i.imgur.com/J3Os8HY.png)

## Parametric Point
>![](https://i.imgur.com/Ll4gHxV.png)

>![](https://i.imgur.com/5N7Uevg.png)

