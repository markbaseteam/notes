[[Circle]]
# Properties of Circle
>![](https://i.imgur.com/SU4sJKa.png)

>![](https://i.imgur.com/Mdut8Yq.png)

>![](https://i.imgur.com/XAfETY4.png)