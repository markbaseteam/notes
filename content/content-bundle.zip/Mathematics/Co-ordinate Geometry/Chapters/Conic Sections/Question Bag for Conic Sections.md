---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Saturday, May 21st 2022, 8:38:28 pm
date modified: Friday, May 27th 2022, 3:04:00 pm
title: Question Bag
---

[[Conic Sections MOC]]

# Question Bag
## 1. Points Passing Through the Circle

1. If Points are given that say, they they pass through the circle, then make them satify the Standard 2gx + 2fy equation.


## 2. Triangle Equality
+ $AO\times AB = PA\times AQ$
>[!ques] Question to Expand on the Above General Idea
>![](https://i.imgur.com/W7KN6Um.png)
>![](https://i.imgur.com/THPXfdt.png)



## 3. Constants
+ The Farthest Distance from Point A anywhere on the plane to the Point B anywhere on the Circle is the Distane Between the Point A to the Center of the Circle + Radius of the Circle.


>[!visill] Visual Illustration of above Concept
>![](https://i.imgur.com/FCZ7c6j.png)


## 4. Trigonometric Angles
1. Whenever you have to find out the angles  which subtend at the center play with the half angle, as you may apply pythagorous, Propoerty and other thing there. Remeber to play with the half angle.

## 5. Tangent
+ You can also take out the slope to the Curve of a Tangent. If you asked about a constant in the Equation.

