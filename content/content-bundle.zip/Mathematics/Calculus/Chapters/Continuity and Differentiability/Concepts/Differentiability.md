---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Wednesday, June 1st 2022, 11:06:34 am
date modified: Wednesday, June 1st 2022, 11:10:54 am
title: Differentiability
---

[[Continuity and Differentiability MOC]]

# Differentiability

+ Function mein Sharp Point aajaye ya function ekdum badal jaye toh function wahan differentiable nahi hota hain

>[!conc] Concept of Existence of Derivative
>![](https://i.imgur.com/BUTSDD8.png)


+ Right Hand Derivative = Left Hand Derivative




## 1. Differentiability in an Interval

### 1.A. Open Interval
>[!conc] Concept of an Open Interval
>![](https://i.imgur.com/l2J3acI.png)

### 1.B. Closed Interval

>[!conc] Concept of Closed Interval
>![](https://i.imgur.com/zu7Hqx7.png)



## 2. Manipulation Techniques
>[!lecpg] Lecture Slide for Manipulation Techniques
>![](https://i.imgur.com/R9u6vpO.png)
+ We do not have to equate, infact we have to find that at the Doubtful points how does my function behave or in particular is my function differentiable at x=1 and from that we may form formulas and get our answers.


