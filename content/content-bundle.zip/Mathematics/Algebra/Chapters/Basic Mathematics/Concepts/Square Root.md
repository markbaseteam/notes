---
type : 
subject : 
type : 
subject : 
date created: Friday, May 20th 2022, 5:58:35 pm
date modified: Friday, May 20th 2022, 5:59:01 pm
title: Square Root
---
[[Basic Mathematics MOC]]

# Square Root
1. >[!conc] Concept of Square Root
>Square root of a number is modulus of that number
>1. >[!ltex] Mathematical Illustration
>$$\sqrt{x}=|x|$$