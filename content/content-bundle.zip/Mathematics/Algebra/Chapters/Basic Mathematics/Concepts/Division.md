# Division
> $$Dividend = Divisor * Quotient + Remainder$$
> ![](https://i.imgur.com/6nrlRTx.png)
