---
type : 
subject : 
branch :
chapter :
date created: Saturday, May 28th 2022, 11:51:01 am
date modified: Monday, May 30th 2022, 12:01:16 am
title: Polar & Euler Form
---
[[Complex Number MOC]]

# Polar & Euler Form

## Polar Form

>[!note]- Lecture Slide for Polar Form of Complex Number
>![](https://i.imgur.com/nhBtBln.png)

### Manipulating the Polar Form

>[!note]- Lecture Slide for Manipulating the Polar Form of a Complex Number
>![](https://i.imgur.com/5DYfzQi.png)

## Euler Form

>![](https://i.imgur.com/rrTEkEE.png)
