---
type : 
subject : 
branch :
chapter :
date created: Saturday, May 21st 2022, 8:38:28 pm
date modified: Friday, May 27th 2022, 3:02:50 pm
title: De-moiver's Theorem
---
[[Trigonometry MOC]]

# De-moiver's Theorem

>[!note]- De-moiver's Theorem
>![](https://i.imgur.com/8n3Sr4L.png)
