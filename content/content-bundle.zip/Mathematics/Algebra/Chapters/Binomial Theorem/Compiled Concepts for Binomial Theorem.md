---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Saturday, May 28th 2022, 11:51:01 am
date modified: Monday, May 30th 2022, 8:55:36 am
title: Compiled Concepts for Binomial Theorem
---

[[Binomial Theorem MOC]]

# Compiled Concepts for Binomial Theorem


## 1. Functions
+ No, of Discontinuous and Differentiable points are like
>[!ex] An Example of Functions
>![](https://i.imgur.com/RNatiF9.png)
>![](https://i.imgur.com/NJ5y7qf.png)
>It has n (0) discontinuos Points and m (4) Differentiable points




## 2. Basic Mathematics
+ >[!conc] Concept of $a^3 - b^3$
>![](https://i.imgur.com/rUaUbS7.png)
