---
type : 
subject : 
branch :
chapter :
type : Concept
subject : Mathematics
branch : Algebra
chapter : Binomial Theorem
date created: Saturday, May 21st 2022, 9:55:13 am
date modified: Saturday, May 21st 2022, 9:57:20 am
title: Properties of Binomial Coefficients
---

[[Binomial Theorem MOC]]

# Properties of Binomial Coefficients

1. >[!ltex] Mathematical Illustration
>![](https://i.imgur.com/iCIHaWP.png)

2. >[!ltex] Mathematical Illustration
>![](https://i.imgur.com/6OkmO3p.png)

3. >[!ltex] Mathematical Illustration
>![](https://i.imgur.com/WhtV1Sj.png)

4. >[!ltex] Mathematical Illustration
>![](https://i.imgur.com/zrpQinc.png)
