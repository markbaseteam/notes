---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Saturday, May 21st 2022, 12:41:07 pm
date modified: Saturday, May 21st 2022, 12:43:05 pm
title: Question Bag for Complex Numbers
---
[[Complex Number MOC]]
# Question Bag for Complex Numbers

## 1. Modulus of a Complex Number
+ To find the minimum distance between |z-P(A,B)| is the perpendicular distance. Refer to the following example
>[!ques] Question
>![](https://i.imgur.com/lWMnBcH.png)
>![](https://i.imgur.com/wehMepk.png)
