---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Saturday, May 21st 2022, 12:41:17 pm
date modified: Saturday, May 21st 2022, 12:41:28 pm
title: 0.0.0.0.0.1 Compiled Concepts for Complex Numbers
---
[[Complex Number MOC]]
# Compiled Concepts for Complex Numbers


## 1. Inverse Trigonometry Functions
+ You may resolve arguments by taking $\tan^{-1}(\frac{Im(Z)}{Re(Z)})$ and by applying the Properties of Inverse Trigonometric Functions

>[!ques] Question to Illustrate above Concept in action
>![](https://i.imgur.com/Wv4EnUn.png)




## 2. Circles
+ To Verify that in the Sets Question, that the Point Lies in the Circle or Not, Try to Only Once Verify the Points by putting them into the Equation of Circle.

>[!ques] Question to Illustrate the Above Concept
>![](https://i.imgur.com/9kFnCiq.png)
>![](https://i.imgur.com/Z5ffrC5.png)



## 3. Integration
+ Integration of sin x d x is
>[!visill] Visual Illustration
>![](https://i.imgur.com/3U9g8VZ.png)
