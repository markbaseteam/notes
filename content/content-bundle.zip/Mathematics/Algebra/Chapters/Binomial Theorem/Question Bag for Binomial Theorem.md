---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Saturday, May 28th 2022, 11:51:01 am
date modified: Monday, May 30th 2022, 8:55:20 am
title: Question Bag for Binomial Theorem
---

[[Binomial Theorem MOC]]

# Question Bag for Binomial Theorem


## 1. Summation Series
+ Whenever a Summation Series is given to you always use the properties of Summation Operator to understand how such composite relationships will be formed
>[!ques] Question
>![](https://i.imgur.com/gxHQFCj.png)

>![](https://i.imgur.com/PC33SCC.png)
+ Note that to find out the sum of this composite series use Sigma Notation and use their Properties to Solve a Question.



## 2. Value of an Infinite Term of an Binomial Expansion
+ >[!conc] Concept
>![](https://i.imgur.com/CWMki2O.png)



## 3. 3.Rational Terms
+ If it asks for Sum then you must check that the terms will be few numbers and the powers will be computable while for the number of terms power may not be computable, in that case find out the value of r in form of $\lambda I$, where $I \in Integer$ and find out possible values of I