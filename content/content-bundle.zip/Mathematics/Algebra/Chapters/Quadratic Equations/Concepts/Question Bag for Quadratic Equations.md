---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Monday, May 23rd 2022, 12:50:16 am
date modified: Monday, May 23rd 2022, 12:51:03 am
title: Question Bag for Quadratic Equations
---
[[Quadratic Equations MOC]]
# Question Bag for Quadratic Equations

## Manipulation

1. The Roots that Satisfy the Equation play with them to come up with some other realtions.


## Inequality
1. Condition for validity of Equation for every x in R is a>0 and D<0
2. Agar Kisi Root ko lie karwana hain kisi interval mein then us interval ki first aur last value ko quadratic equation mein daalke uske 0 se chhoota hona chahiye.