# Equations
## Transformation of Equations
To avoid Desired roots method at specific cases we use Transformation of Equations
### How to Apply
>![](https://i.imgur.com/BxkauSr.png)

### When to Apply
1. This method is applicable in scenarios when both of the new roots are formed by manipulating the given roots following the same process.
2. This method is applicable to any degree polynomial Equation
