[[Sequence and Series MOC]]
# Geometric Progression
>![](https://i.imgur.com/4aQW8yh.png)

>![](https://i.imgur.com/pMvkyp0.png)

## Properties of G.P
1. >![](https://i.imgur.com/rujGuQK.png)
2. >![](https://i.imgur.com/Ow1RFx4.png)
3. >![](https://i.imgur.com/eHcW43T.png)
4. >![](https://i.imgur.com/tjuWCE8.png)
5. >![](https://i.imgur.com/1L4dI9Q.png)

## Selection of Terms in G.P
>![](https://i.imgur.com/rSOaKvK.png)

## Geometric Mean (G.M)
>![](https://i.imgur.com/mYvQRak.png)

>[!FAQ]- G.M of Series of numbers
>![](https://i.imgur.com/gTeEQHC.png)

>![](https://i.imgur.com/Ao5WjSl.png)
