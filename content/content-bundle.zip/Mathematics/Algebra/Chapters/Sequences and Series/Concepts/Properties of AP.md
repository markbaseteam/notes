[[Arithmetic Progression]]

# Properties of A.P
## 1st
>![](https://i.imgur.com/2TUjL89.png)

## 2nd
>![](https://i.imgur.com/CLnZNJa.png)

## 3rd
>![](https://i.imgur.com/3kfsZdj.png) #important 

## 4th
>![](https://i.imgur.com/j3W29Yn.png)

## 5th
>![](https://i.imgur.com/qWNY7mT.png)

## 6th
>![](https://i.imgur.com/DcnKxNk.png)

## 7th #important 
>![](https://i.imgur.com/lhI9Yh2.png)

## 8th
>![](https://i.imgur.com/C9WdU81.png)
