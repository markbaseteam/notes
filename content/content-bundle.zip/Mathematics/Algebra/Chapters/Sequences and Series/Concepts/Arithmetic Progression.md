# Arithmetic Progression
1. When Sum of n terms are in Quadratic of n then that Summation is of A.P

>![](https://i.imgur.com/RCxf1qf.png)

>![](https://i.imgur.com/hYZZbEC.png)

## 1. [[Properties of AP]]
## 2. Selection of terms in A.P
>![](https://i.imgur.com/La3lnh8.png)

## 3. Arithmetic Mean
>![](https://i.imgur.com/KDX1nif.png)

>![](https://i.imgur.com/imKniYd.png)
