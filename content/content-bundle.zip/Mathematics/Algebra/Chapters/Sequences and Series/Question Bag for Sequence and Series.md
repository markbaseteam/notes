---
type : 
subject : 
type : 
subject : 
date created: Wednesday, May 11th 2022, 4:48:37 am
date modified: Friday, May 20th 2022, 8:13:57 pm
title: Question Bag
---

# Question Bag

## Concepts From Sequence and Series

1. To get $d$ one by one check multiplication of each term and its sign equate each term with d which satisfies its equation.
>![](https://i.imgur.com/VO1ZM6Q.png)

2. When you take two, three or four terms of an A.P then all the Equations involving a and d will change.

## Summation of Series

1. Subtract the Highest Term from the lowest term in the series and place it in the numerator
>[!ques] Question for the Application of above concept
>![](https://i.imgur.com/R0dCe3k.png)
