---
type : 
subject : 
type : 
subject : 
date created: Friday, May 20th 2022, 8:39:56 pm
date modified: Friday, May 20th 2022, 8:42:13 pm
title: Multiplication and Addition Rule
---
[[Permuations and Combinations MOC]]

# A Multiplication and Addition Rule
## 1 Addition Rule
When we have a choice that is either this or that.
## 2 Multiplication Rule
When we have a condition or inclusion of conditions
***
>[!lecpg] Lecture Slide for Summary of the <mark class="hltr-blue">Addition and Multiplication Rule</mark> 
>![](https://i.imgur.com/fEQwIQJ.png)
