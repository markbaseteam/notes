---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Sunday, May 29th 2022, 10:16:19 pm
date modified: Sunday, May 29th 2022, 10:16:22 pm
title: Battery and Circuits
---


[[Current Electricity MOC]]
# Battery and Circuits

>[!lecpg] Lecture Slide for Initial Understanding of Battery and Circuits
>![](https://i.imgur.com/5gQra7D.png)
+  Battery tabh discharge hoti hain jub, battery ke Positive End se Current Nikal Raha hain.



>[!ex] An Example for Calculation of Current along a Resistor connected to a Battery
>![](https://i.imgur.com/F0eZc6l.png)



## 1. Multiple Batteries
### 1.A. Series Combination
>[!lecpg] Lecture Slide for Above Concept
>![](https://i.imgur.com/HcqubNr.png)



>[!ex] An Example of Series Combination of Multiple Batteries
>![](https://i.imgur.com/nxhbqox.png)




## 2. Parallel Combination
>[!lecpg] Lecture Slide for Parallel Combination
>![](https://i.imgur.com/4AqhHYr.png)


>[!ex] An Example of Prallel Combinations of Multiple Batteries
>![](https://i.imgur.com/rZbhOBF.png)


### 2.A. Nodal Analysis
>[!lecpg] Lecture Slide for Nodal Analysis with an Example
>![](https://i.imgur.com/ddmQm8Q.png)
