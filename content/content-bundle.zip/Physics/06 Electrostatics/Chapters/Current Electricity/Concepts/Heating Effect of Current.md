---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Sunday, May 29th 2022, 10:56:28 pm
date modified: Sunday, May 29th 2022, 10:56:33 pm
title: Heating Effect of Current
---

[[Current Electricity MOC]]

# Heating Effect of Current
>[!lecpg] Lecture Slide for Above Concept
>![](https://i.imgur.com/IeIBsUs.png)

+ P is power dissipated through ir
+ If we differentiate P we find that Kisi Bhi Load Resistance ke through Power Maximum tubh hoti hain when $r = R$
+ >[!conc] Concept of Heating Effect with Relation to Voltage
>![](https://i.imgur.com/HDAlrA9.png)





## 1. Comparison of Brightness and Heat Dissipation
>[!lecpg] Lecture Slide for Comparison of Brightness in Parallel Combination and Series Combinaiton of Resistors
>![](https://i.imgur.com/TLyAUoB.png)
+ In Series Connection, $Power \propto Resistance$
+ In Parallel Connection, $Power \propto \frac{1}{Resistance}$
+ Power Rating of the Buld means that at 220V of Current the Bulb will consume 50 Watts of Energy

>[!ex] An Example of Computation of Brightness and Power of the Bulbs
>![](https://i.imgur.com/eV90Sgr.png)
