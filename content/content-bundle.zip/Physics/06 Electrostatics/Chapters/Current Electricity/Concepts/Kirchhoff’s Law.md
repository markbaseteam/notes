---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Sunday, May 29th 2022, 10:24:21 pm
date modified: Sunday, May 29th 2022, 10:24:25 pm
title: Kirchhoff’s Law
---

[[Current Electricity MOC]]

# Kirchhoff’s Law

## 1. Junction Law
>[!lecpg] Lecture Slide for Junction Law
>![](https://i.imgur.com/foqFNA8.png)
+ Conservation of Charge


## 2. Loop Law
+ Conservation of Energy

>[!lecpg] Lecture Slide for Loop Law
>![](https://i.imgur.com/RGJk5Ll.png)
+ Battery ke Low se High Pe Jaoge toh potential ki value + mein likhni padegi
+ Loop Law kehta hain ki net potential drop kisi bhi point mien ghoom ke aane ke baad ZERO hO jana chahiye.





+ All Circuits in Parallel Behave Independently, isiliiye Potential Difference Across Two Points joh simple circuit ko Independent maan ke banaya gaya tha usi tarah chahe kitna bhi complex parallal circuit ho, potential difference across A and B same rahega.
>[!visill] Visual Illustration
>![](https://i.imgur.com/pbSioOR.png)


+ 