[[Mechanical Properties of Solids MOC]]
1. Searle's Appratus is used to Calculate Young's Modulus
2. 