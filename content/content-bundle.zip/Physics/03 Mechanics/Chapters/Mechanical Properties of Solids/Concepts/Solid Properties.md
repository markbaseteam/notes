1. Yeh Body ki property hain ki voh Lage Hue Force pe kaise react karein.

## Properties of Solid
1. Perfectly Elastic
Completely Regains the Original Shape and Size

2.  Elastic
Does not regain completely but Partially

3. Plastic
Does not regain

### Restoring Force
Whenever __DEFORMATION__ occurs, __RESTORATION__ force arises.