---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Saturday, May 28th 2022, 11:51:02 am
date modified: Sunday, May 29th 2022, 12:24:30 am
title: 1. Motion in One Dimension
---

[[Oscillations and Waves MOC]]
# Compiled Concepts for Waves


1. First Overtone is Second Harmonic
2. Fundamental Frequency
	1. $$F_{o} = \frac{v}{2l}$$
3. Nth Harmonic :
	1. $$F_{n} = \frac{nv}{2l}$$
4. Joh Harmonic Hota hain voh Apne Fundamental Loops Ke Integral Multiple mein hota hain
5. Octave RelationshiP between 2 Fequences F1 AND F2 = 2F1 = F2
6. Questions Jahan Pe Beat Frequency Ki Baat Ki Jaaye toh Yaa toh Frqequncey ko Difference Ki Format mein Likh Ke chhod do ya toh Koi se Bhi Experiment Karlo
7. You may take Square of Velocity of the Fork os An object as 0
8. For A Resonance Tube Length = $(2n-1)\frac{\lambda}{4}$
9. The Fequencey of Tuning Fork Decreases with Temperature given by $\sqrt{\frac{Y}{\rho}}$
10. To form a node there should be superposition with the refelcted wave. With Opposite Direction and Phase Chnage of Pi

# 1. Motion in One Dimension

1. To Find the Distance Reached when Hearing Certain Apparent Freqency
>[!conc] Concept
>![](https://i.imgur.com/Chgo4DX.png)


## 1. Mechanical Properties of Solids
>[!conc] Concept of Basic Application of Mechanical Properties of Solids
>![](https://i.imgur.com/9g6wtXp.png)


>[!ques] Question to Illustrate above concept
>![](https://i.imgur.com/Y6By7BR.png)



## 2. Work Power and Energy
$I = P/A$