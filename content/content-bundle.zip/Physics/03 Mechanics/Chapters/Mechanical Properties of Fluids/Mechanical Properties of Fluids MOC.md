---
date created: Friday, June 3rd 2022, 9:20:05 am
date modified: Tuesday, June 14th 2022, 2:12:00 pm
title: Mechanical Properties of Fluids
---
>[[Mechanics Map of Content|Mechanics]]

# Mechanical Properties of Fluids

## 1. [[Fluid Static]]

## 2. [[Fluid Dynamics]]

## 3. [[Viscosity]]

## 4. [[Surface Tension]]

## 5. Concepts
Reynold's Number
When Reynold's Number is $\lt$ 2000 fluid is in Laminar Streamline State and when $\gt$ 3000 fluid is in Turbulency

>[example]- Visualization and Application of the Above Concept
![](https://i.imgur.com/AuDEJlE.png)
