# Question Bag for Mechanical Properties of Fluids
1. When the Flow of water is stopped from the Orifice, it is due to reduction of pressure inside the vessel. Even, less than the Atmospheric Pressure, so the Flow Stops, apply $P_1V_1=P_2V_2$ and you will get the answer to the Height or any other thing.
2. Bubble is a Water Thin Film which has air inside and outside compared to the Drop having water inside and Air Outside.
3. We can safely cut $\pi^2$ by $10$
4. Try Writing Force of Buoyancy in terms of Mg When Volume and Density is Given
5. $10^{-3}Pa s$ and $Nsm^{-3}$ is the S.I Unit of Viscosity of Water 
6. Finding the Radius of Curvature of Common Surface:
	1. $$\frac{1}{R}=\frac{1}{a}-\frac{1}{b}$$
7. In Milikan's Oil Drop Experiment, the Rate of Viscoity and and Force on the Body is Same at Terminal Velocity.
8. 