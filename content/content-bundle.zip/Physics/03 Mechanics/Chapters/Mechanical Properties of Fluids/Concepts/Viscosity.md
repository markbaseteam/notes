# Viscosity
![](https://i.imgur.com/BGIXY0l.png)


## Velocity Gradient
Rate of change of velocity with Height

## Illustration on Velocity
>![](https://i.imgur.com/3f4E5Uj.png)

## Stroke's Law & Terminal Velocity
>![](https://i.imgur.com/0w9rfs7.png)
>![](https://i.imgur.com/ugVZMjq.png)
