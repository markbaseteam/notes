---
number headings: auto, first-level 1, max 6, _.1.A.
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Friday, May 27th 2022, 9:28:21 am
date modified: Friday, May 27th 2022, 9:31:12 am
title: Magnetic Effect of Current and Magnetism
---

[[Electromagnetics Map of Content]]
# Magnetic Effect of Current and Magnetism

## 1. [[Magnetic Field]]

## 2. [[Force Due to Magnetic Field]]

## 3. Magnetic Properties

## 4. Earth's Magnetism
