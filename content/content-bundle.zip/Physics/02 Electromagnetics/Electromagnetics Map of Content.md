[[Physics MOC]]
# Electromagentics


## 1. Magnetic Effect of Current and Magnetism
1. [[Magnetic Effect of Current and Magnetism MOC|Magnetic Effect of Current and Magnetism]]
2. [[Question Bag for Magnetic Effect of Current and Magnetism|Question Bag]]
3. [[Compiled Concepts for Magnetic Effect of Current and Magnetism|Compiled Concepts]]
