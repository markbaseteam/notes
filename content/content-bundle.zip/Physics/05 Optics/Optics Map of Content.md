---
date created: Thursday, May 26th 2022, 8:58:36 pm
date modified: Tuesday, June 14th 2022, 1:58:44 pm
title: Optics
---

>[[Physics MOC|Physics]]
# Optics

## 1. Ray Optics

1. [[Ray Optics MOC|Ray Optics]]
2. [[Question Bag for Ray Optics|Question Bag]]
3. [[Compiled Concepts for Ray Optics|Compiled Concepts]]

## 2. Wave Optics

1. [[Wave Optics MOC|Wave Optics]]
2. [[Question Bag for Wave Optics|Question Bag]]
3. [[Compiled Concepts for Wave Optics|Compiled Concepts]]
