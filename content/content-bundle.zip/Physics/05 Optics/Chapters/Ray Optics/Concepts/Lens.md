---
type : Concept
subject : 
branch : 
chapter : 
date created: Monday, June 13th 2022, 12:35:58 pm
date modified: Monday, June 13th 2022, 1:47:03 pm
title: Lens
---

> <mark class="hltr-blue">Link</mark> : [[Ray Optics MOC|Ray Optics]]
> <mark class="hltr-cyan">Tag</mark>  :

# Lens

>[!conc] Concept of Variations of Lens
>![](https://i.imgur.com/T3zjb9P.png)
+ Aperture $\propto$ Intensity

## 1. Lens-Maker's Formula

>[!lecpg] Lecture Slide for Len's Maker Formula
>![](https://i.imgur.com/NiYirnt.png)

### 1.A. Focus on Equi-Convex

>[!lecpg] Lecture Slide for Focus on Equi-Convex
>![](https://i.imgur.com/2FVBzpp.png)

### 1.B. Focus on Bi-Concave

>[!lecpg] Lecture Slide for Focus on Bi-Concave
>![](https://i.imgur.com/4eNHwC6.png)

## 2. Magnification

>[!lecpg] Lecture Slide for Magnification
>![](https://i.imgur.com/qHhFlNt.png)

### 2.A. Convex or Convergent Lens

>[!lecpg] Lecture Slide for Magnification of image at different poisitons of Object and Image
>![](https://i.imgur.com/GgHlZJF.png)

### 2.B. Concave or Diverging Lens

>[!lecpg] Lecture Slide for Concave or Diverging Lens
>![](https://i.imgur.com/54Lrvf8.png)



## 3. Power of a Lens
>[!lecpg] Lecture Slide for Power of a Lens
>![](https://i.imgur.com/krZfdyd.png)
+ It is measured in Dioptre $(D)$
+ Focal Length must be in meter $(m)$

## 4. Combination of Lenses
>[!ex] An Example of Combination of Lenses (1)
>![](https://i.imgur.com/QerTFWl.png)


>[!ex] An Example
>![](https://i.imgur.com/gd5Trm2.png)
