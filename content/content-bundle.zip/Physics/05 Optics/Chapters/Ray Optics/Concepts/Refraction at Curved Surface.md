---
type : Concept
subject : 
branch : 
chapter : 
date created: Monday, June 13th 2022, 11:09:45 am
date modified: Monday, June 13th 2022, 11:36:02 am
title: Refraction at Curved Surface
---

> <mark class="hltr-blue">Link</mark> : [[Ray Optics MOC|Ray Optics]]
> <mark class="hltr-cyan">Tag</mark>  :

# Refraction at Curved Surface

## 1. Refraction

>[!lecpg] Lecture Slide for Refraction
>![](https://i.imgur.com/lcSb1ND.png)

>[!ex] An Example
>![](https://i.imgur.com/PXPhJbh.png)

### 1.A. Two Spherical Surfaces

>[!lecpg] Lecture Slide for Above Concept
>![](https://i.imgur.com/XGNAae9.png)
+ Do Baar hoga Refraction, Event wise nikaal lo

## 2. Lateral Magnification

>[!conc] Concept of Lateral
>![](https://i.imgur.com/UvIBk8q.png)




## 3. Focal Length of a Single Spherical Surface
>[!conc] Concept
>![](https://i.imgur.com/VFz9BRs.png)

