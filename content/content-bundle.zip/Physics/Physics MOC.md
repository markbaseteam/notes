---
number headings: auto, first-level 1, max 6, _.1.A.
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Saturday, May 21st 2022, 8:38:29 pm
date modified: Tuesday, May 24th 2022, 11:24:39 am
title: Physics MOC
---
> [[JEE-MOC|JEE]]

# Physics MOC

## 1. [[Classical Mechanics Map of Content|Classical Mechanics]]
## 2. [[Mechanics Map of Content|Mechanics]]
## 3. [[Electrostatics Map of Content|Electrostatics]]
## 4. [[Electromagnetics Map of Content|Electromagnetics]]
## 5. [[Cards/Physics/04 Thermodynamics/Thermodynamics Map of Content|Thermodynamics]]
## 6. [[Optics Map of Content|Optics]]
## 7. [[Modern Physics Map of Content|Modern Physics]]