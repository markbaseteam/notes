---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Tuesday, May 24th 2022, 4:05:09 pm
date modified: Tuesday, May 24th 2022, 4:05:26 pm
title: Question Bag for Center of Mass
---

[[Center of Mass MOC]]

# Question Bag for Center of Mass

## Elastic Collision
1. >[!conc] Method of Solving Elastic Collision Type Questions
> ![](https://i.imgur.com/Jy3QMFz.png)

>1. Conservation of Linear Momentum Equation
>2. Coefficient of Restituition Equation 



## Non-Uniform Mass Density
>[!ques] Question #short-trick 
>![](https://i.imgur.com/x44XPXn.png)
>Put $b = 0$ to convert mass density of rod from Non-Uniform to Constant i.e. uniform. Then we know Center of Mass for Uniform Mass Density Rod is $L/2$, checking all other options by putting $b = 0$, we only find Option C to correspond to correct Uniform Mass Density of Rod and hence the Option C is correct
