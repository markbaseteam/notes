[[Motion in a Plane MOC]]
# 2D Motion
1. Motion in 2 Perpendicular $(\perp)$ is independent of each other.
2. Two Dimensional motion is One Dimensional motion in $X$ and $Y$ Axes
3. All [[Motion#Equations of Motion|Equations of motions]] are valid Separately in X and Y directions. i.e. $V_x$ and $V_y$ are different velocities in X and Y
4. When $\theta$ between Velocity and Acceleration is $\neq 0\textdegree$ then the Motion is Parabolic in Nature
5. Air Drag is assumed to be Neglected in Projectile Motion #assumption 