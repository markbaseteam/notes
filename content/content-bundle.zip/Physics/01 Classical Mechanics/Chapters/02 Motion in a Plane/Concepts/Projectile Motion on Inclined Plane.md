[[Projectile Motion]]
# Projectile Motion on Inclined Plane

>![](https://i.imgur.com/mz1dgu1.png)

>![](https://i.imgur.com/oPAtin6.png)
