[[Motion in a Plane MOC]]
# Circular Motion
>![](https://i.imgur.com/GT0oQnJ.png)

>![](https://i.imgur.com/IW0F3Cl.png)

>![](https://i.imgur.com/OqD6tfI.png)

>![](https://i.imgur.com/WNYtXRG.png)

>![](https://i.imgur.com/d4kOaSs.png)
