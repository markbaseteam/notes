---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Saturday, May 21st 2022, 8:38:29 pm
date modified: Friday, May 27th 2022, 2:51:15 pm
title: Compiled Concepts
---
[[Motion in a Plane MOC]]
# Compiled Concepts

## 1. Concepts From Motion in a Plane

1. Jub bhi acceleration theda ho, koshish karo use seedha karne ke (Vectorally)
>[!EXAMPLE]- Question Answer
>![](https://i.imgur.com/aggob1w.png)

2. Vector ka Direction Dekho Jub Same Ho Jaye toh Motion Straight Line ka hain
>[!example]- Visualization and Application of Above Concept
>![](https://i.imgur.com/zHJIPe8.png)
