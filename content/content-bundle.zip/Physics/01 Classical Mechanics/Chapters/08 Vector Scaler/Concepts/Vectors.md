---
type : Concept
subject : 
branch : 
chapter : 
---

> <mark class="hltr-blue">Link</mark> : [[Vector Scaler MOC|Vectors and Scalers]]
> <mark class="hltr-cyan">Tag</mark>  :

# Vectors
# Vector
1. __Origin__ is the Reference Point

## 1. Magnitude
Magnitude of the Vector is the Square root of the Sum of the Square of each Vector component
$$\vec {AB} = x\hat i + y \hat j$$
$$|\vec{AB}| = \sqrt{x^2+y^2}$$ ^f8a29c
## 2. Direction
Negative Sign with a Vector denotes Negative Direction of the concerned vector
### 2.A. Dot Products of Two Vectors
![[Pasted image 20220502191948.png]]