---
date created: Tuesday, May 3rd 2022, 4:09:40 pm
date modified: Friday, May 20th 2022, 1:40:06 pm
title: Kinetic Energy
---

# Kinetic Energy

[[Energy]]
Kinetic Energy = $\frac{1}{2}*m*{v^2}$
Kinetic Energy is $0$ when velocity is $0$
