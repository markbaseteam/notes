---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Saturday, May 21st 2022, 8:38:29 pm
date modified: Friday, May 27th 2022, 2:57:14 pm
title: '$3^{rd}$ Law of Motion'
---

[[Laws of Motion]]

# $3^{rd}$ Law of Motion

Forces always act in Pair
