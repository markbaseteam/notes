---
type : Concept
subject : 
branch : 
date created: Saturday, May 21st 2022, 8:38:29 pm
date modified: Saturday, May 21st 2022, 8:29:23 pm
title: Force
---

> <mark class="hltr-blue">Link</mark> : [[Laws of Motion]]
> <mark class="hltr-cyan">Tag</mark>  :

# Force

>[!tip] If a number of forces act on a body and the body is in static or dynamic equilibrium, then Net work done is $0$

## 1. Types of Forces
1. Gravitational Force
2. Electromagnetic Forces (Due to Intermolecular Interaction)
3. Strong Forces
4. Weak Forces




## 2. Dynamic Equilibrium

$V \neq 0$ but $F = 0$

## 3. Static Equilibrium

$V = 0$ and $F = 0$
