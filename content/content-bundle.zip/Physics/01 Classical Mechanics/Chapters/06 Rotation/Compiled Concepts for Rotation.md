---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Thursday, May 26th 2022, 2:03:10 pm
date modified: Thursday, May 26th 2022, 2:04:58 pm
title: Compiled Concepts for Rotation
---

[[Rotation MOC]]

# 0.0.0.0.0.1 Compiled Concepts for Rotation

## Tricks and Tips
+ >[!conc] Concept of Moment of Inertia for a Cuboid Cut in Half from Axis of Rotation [Physics Galaxy](https://youtu.be/zt7CS64_lpk?t=292)
>![](https://i.imgur.com/HQnDRe1.png)
>![](https://i.imgur.com/VTdvqRE.png)
