---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Thursday, May 26th 2022, 8:23:30 pm
date modified: Thursday, May 26th 2022, 8:23:51 pm
title: Torque
---

[[Rotation MOC]]

# 0.0.0.0.0.1 Torque
+ Torque is a moment of a force


>[!ltex] Mathematical Illustration
>$$\vec \tau = \vec r \times \vec F\sin\theta$$
>Where $r$ is the position vector of Point of Application of Force



>[!lecpg] Lecture Slide for Reference (Optional)
>![](https://i.imgur.com/Sq3mLGs.png)


## 1. Calculation of Torque
+ For Calculation of **Torque**, we may assume the whole mass of the body to be concentrated at its <mark class="hltr-cyan">center of mass</mark> 
+ Line of Force kheecho aur hinge se doori le lo
+ We Prefer <mark class="hltr-cyan">Clockwise Direction</mark> that is Into the Plane to be of <mark class="hltr-blue">Negative Direction</mark> 
+ We Prefer <mark class="hltr-cyan">Anti-Clockwise</mark> Direction that is <mark class="hltr-blue">out of the plane</mark> to be of <mark class="hltr-blue">Positive Direction</mark> 
### 1.A. Alternative
>[!lecpg] Lecture Slide for Reference (Optional)
>![](https://i.imgur.com/d1hrJrZ.png)


>[!ltex] Mathematical Illustration
>$$\vec \tau = F\times l\cos\theta$$