# Circular Motion

### Work Done by Circular Motion
1. ![](https://i.imgur.com/zBXsJkz.png)
2. Work Done = $\tau * \theta$