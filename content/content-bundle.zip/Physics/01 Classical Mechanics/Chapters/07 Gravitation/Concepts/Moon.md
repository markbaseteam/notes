# Moon
Moon is our natural Satellite

>[!faq]- Why does moon have No Atmosphere?
>Velocity of Gases at the Moon's Surface Temperature $\gt$ Escape Velocity of the Moon