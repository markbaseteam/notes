# Friction

## Properties
1. Friction is a Self Adjusting Force
	1. Friction jahan jaroori hain vahan lagega
	2. Friction jitna jaroori hain utna lagega
	3. Friction jub zaroori hain tab lagega
2. Friction's max value  = $umg$
3. Work done by Friction is both Positive and Negative
> [!example] Walking is an effect of friction

## Work done by Friction
Refer to [[Work Power & Energy#Work done by Friction]]

## Static Friction
1. Static friction tab legta hain jub do block ek doosre ke respect mein move ==__NAHI__== karte hain
2. Net work done by the static friction is always $0$