# Speed
1. Speed is Distance Travelled upon time taken
## Units and Dimensions
1. Scaler Quantity
2. No Direction only Magnitude

## Average Speed
$\lt \vec v_{speed} \gt$ = Total Distance Travelled / Total Time Taken
1. if [[Velocity#^4a0cea|Distance = Displacement]]
2. if Particle moves with different uniform speed in different time intervals
> ![](https://i.imgur.com/ZaFDhyy.png)
3. if Particle moves with different distances with different speeds
> ![](https://i.imgur.com/rnBVbFA.png)
4. $Average Speed \geq Average Velocity$