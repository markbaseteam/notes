# Distance
1. Length of Actual Path covered by the body is called the __Distance__
2. For Very Small Distance = Magnitude of Displacement #advance 
> $|dx| = distance$
![](https://i.imgur.com/YBeQV7u.png) ^3b0dc1
3. $distance \geq |displacement|$
## Units and Dimensions
1. Scaler Quantity
2. 