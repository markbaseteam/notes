# Displacement
It is the shortest path between two points.
## Displacement Vector
Displacement Vector is equal to the Difference between the Final Position Vector and Initial Position Vector.
### [[Vectors#^f8a29c|Magnitude of Displacement Vector]]
1. Magnitude of Displacement = Very Small [[Distance#^3b0dc1|Distance]]
2. 