# Rest
1. With Respect to a Frame of Reference, if the __Position [[Vectors]]__ of a body are not changing with time, we say the body is at rest.