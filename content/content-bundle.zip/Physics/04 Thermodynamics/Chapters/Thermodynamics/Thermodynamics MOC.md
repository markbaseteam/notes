---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Saturday, May 21st 2022, 8:38:29 pm
date modified: Wednesday, May 25th 2022, 11:41:29 am
title: Thermodynamics
---
[[Cards/Physics/04 Thermodynamics/Cards/Physics/04 Thermodynamics/Thermodynamics MOC]]

# Thermodynamics

## Prerequisite

## 1. [[Definitions]]

## 2. [[Law of Thermodynamics]]

## 3. [[Ideal Gas#Free Expansion|Free Expansion in Ideal Gas]]

## 4. [[Question Bag for Thermodynamics]]
