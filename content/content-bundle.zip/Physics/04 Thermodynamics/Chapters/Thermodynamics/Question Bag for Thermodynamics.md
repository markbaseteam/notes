---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Wednesday, May 25th 2022, 11:41:34 am
date modified: Wednesday, May 25th 2022, 11:42:08 am
title: Question Bag for Thermodynamics
---
[[Cards/Physics/04 Thermodynamics/Thermodynamics/Cards/Physics/04 Thermodynamics/Thermodynamics MOC|Thermodynamics]]
# Question Bag for Thermodynamics

## Degree of Freedom

1. >[!conc] Concept of Degree of Freedom for Non-Linear Triatomic Moelcule
>![](https://i.imgur.com/n8HbkwE.png)
2. Diatomic Non-Rigid Molecules has f=7 Degree of Freedom
3. Triatomic Rigid Molecule has f=6 Degree of Freedom
4. Polyatomic Moelcule has 3 Transalational Motion, 3 Rotational Motion, Since Each Vibrational Mode has 2 Degree of Freedom they are 2*$n$ where n is given in the Question


## Energy of the System
1. >[!conc] Concept of Energy and Molar Specific Heat Capacity at Constant Pressure
>![](https://i.imgur.com/0bD1sH9.png)

##