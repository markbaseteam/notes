[[Cards/Physics/04 Thermodynamics/Thermodynamics/Cards/Physics/04 Thermodynamics/Thermodynamics Map of Content]]
# Standard Thermodynamic Process
>![](https://i.imgur.com/VxsQVCc.png)

## Isobaric Process
>![](https://i.imgur.com/Cw5TjSS.png)

## Isochoric Process
>![](https://i.imgur.com/MwxC5og.png)

## Isothermal Process
>![](https://i.imgur.com/h3kWXfR.png)
>![](https://i.imgur.com/YKBfE5T.png)

## Adiabatic
>![](https://i.imgur.com/KGiCEOe.png)

>![](https://i.imgur.com/mRhmscV.png)

>![](https://i.imgur.com/dFaHTuS.png)
