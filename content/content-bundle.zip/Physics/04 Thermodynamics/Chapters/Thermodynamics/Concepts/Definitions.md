---
type : 
subject : 
branch :
chapter :
date created: Saturday, May 21st 2022, 8:38:29 pm
date modified: Wednesday, May 25th 2022, 11:34:00 am
title: Definitions
---
[[Cards/Physics/04 Thermodynamics/Thermodynamics/Cards/Physics/04 Thermodynamics/Thermodynamics Map of Content]]

# Definitions

## Thermodynamics

### 1. System

>![](https://i.imgur.com/WGUK6vl.png)

#### Heterogeneous System

#### Homogeneous System

#### Walls

##### Isolated/Adiabatic/Insulated

1. >$\Delta Q = 0$

##### Diathermic

In thermodynamics, a diathermal wall between two thermodynamic systems allows heat transfer but do not allow transfer of matter across it.

### 2. State and Energy

>![](https://i.imgur.com/nXAybIF.png)
