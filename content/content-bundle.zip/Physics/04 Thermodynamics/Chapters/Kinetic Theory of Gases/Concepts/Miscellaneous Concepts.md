---
type : 
subject : 
branch :
chapter :
type : 
subject : 
branch :
chapter :
date created: Saturday, May 21st 2022, 8:38:29 pm
date modified: Wednesday, May 25th 2022, 10:44:40 am
title: Miscellaneous Concepts
---

[[Kinetic Theory of Gases MOC]]
# Miscellaneous Concepts

1. Piston has a Friction less Side walls $\implies$ The Piston is freely movable. This is a Setup for Constant Pressure
2. Average Pressure = $P = \frac{1}{3}\frac{m*N*<V>^2}{V}$
3. Energy = f/2 nrt