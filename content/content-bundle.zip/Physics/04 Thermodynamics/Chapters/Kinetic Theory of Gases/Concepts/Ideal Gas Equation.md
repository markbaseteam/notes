# Ideal Gas Equation
>1. $PV=nRT$ is a Conservation of Energy in a Fancy Way
>2. Ideal Gas is a Hypothetical Concept

## Interconversion of Process Equation
1. Example : if $PV^2 = constant$ $\implies$ $TV = constant$
>[!example]- Lecture Slide for Interconversion of Process Equation of an Ideal Gas
>![](https://i.imgur.com/FATS8AX.png)
