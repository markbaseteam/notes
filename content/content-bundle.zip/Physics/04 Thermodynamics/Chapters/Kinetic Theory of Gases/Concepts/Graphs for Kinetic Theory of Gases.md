---
type : 
subject : 
branch :
chapter :
date created: Saturday, May 21st 2022, 8:38:29 pm
date modified: Wednesday, May 25th 2022, 9:26:50 am
title: Graphs
---
[[Kinetic Theory of Gases MOC]]

# Graphs

## Increasing Function

1. When Change in One Quantity brings the same change in the other Quantity.

## Decreasing Function

1. When change in One Quantity brings __Opposite__ or __Inverse__ Change in other Quantity.

## Methods

1. If two graph seems same then formulate the Value of one Quantity when it tends to $\infty$ and then map the other Quantity's Value respect to previous $\infty$ value. This methods helps you define the Borders of the Graphs.

>[!example]- Lecture Slide for Graphs
>![](https://i.imgur.com/Am8piYV.png)
