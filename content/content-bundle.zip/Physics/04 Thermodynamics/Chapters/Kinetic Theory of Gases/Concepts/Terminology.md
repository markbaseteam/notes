---
type : 
subject : 
branch :
chapter :
date created: Saturday, May 21st 2022, 8:38:29 pm
date modified: Wednesday, May 25th 2022, 9:35:58 am
title: Terminology
---

[[Kinetic Theory of Gases MOC]]

# Terminology

>[!example]- Lecture Slide for Terminologies
>![](https://i.imgur.com/z7MPEyv.png)
