---
type : 
subject : 
branch :
chapter :
date created: Saturday, May 21st 2022, 8:38:29 pm
date modified: Friday, May 27th 2022, 2:48:54 pm
title: Question Bag
---
[[Thermal Properties of Matter MOC]]

# Question Bag

## 1. Understanding Language of Question

1. Yahan Pe Dono ke Change in Length ko Equate Kardenge tabh tubh hum yahi keh rahe honge ki Dono ki Differences of two length is independent of Temperature.
>![](https://i.imgur.com/Lt9WAqW.png)

2. Dont fear when some thermodynamics is mixed in the Question its just to increase the pretense posed by the Question, Extract Data.
3. Modulus of Elasticity = $$\frac{\frac{F}{A}}{\Delta L}$$
