# Thermal Properties of Matter
## Prerequisite
### Work, Power and Energy
1. Also Refer to [[Power]]
## 1. [[Heat and Temperature]]
## 2. [[Heat Transfer]]

## Concepts
1. Jub hum Electrically Heat Karte hain in the case of gese, Panni ke Jaane or Aane ko independent dekho. Aur cheeze apply karna bekar hain (Jaise Mixing of Hot and Cold water) because Energy is Conserved.


