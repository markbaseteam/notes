# Convection
1. Medium ke Molecule energy lene ki liye move karte hain.
2. Air Conditioner and Cooler