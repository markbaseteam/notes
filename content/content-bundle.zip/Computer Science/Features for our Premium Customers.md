---
date created: Sunday, June 12th 2022, 10:11:29 pm
date modified: Tuesday, June 14th 2022, 11:11:51 am
title: Features for Our Premium Customers
---

# Features for Our Premium Customers

1. Community Support
2. Live Coding Jams
3. Obsidian Linked Notes
4. Weekly Leaderboard
5. Dedictaed App
6. Organised Material
7. Animated and Well Thought Content
8. Hand Holding and Support
9. Animation Control Panel
	1. When you make notes by taking Screenshot, the system istelf undertsnds what is deviation from the previous frame and makeis it an animation according to the Settings.
10. Picture Hook
11. Proof by Running Programs and Showing Documentation
12. Higher Emphsis on Reading Documentation
13. Programmer Friendly Guide by Personalizing with a Name, Nouns and Verbs
14. Time-Line Feature (Pointing the Topics in advance)
15. Progress Stop (You can't go ahead before solving Questions)
16. Energy Bar (Only Certain number of New Lectures allowed to See, then replenish the Energy Bar)
17. What has Some Books to Say about ...
18. Example Generator for Each Topics
19. Critical Thinking Section (Questions that open your concepts)
20. Question Genertor (Very Advance)
	1. Concept Specific Question Template
	2. Template Flavour (Additions to Template Itself regarding manipulations inside Templates)
		1. Parameter Relation Specifier
	3. Answer Logic Judge
	4. Options or Question Type Specifier
	5. Question Layout Placer
	6. Tagger
	7.
21. Yaad Rakhna Prompt
	1. System Generates a Good Question helping you memorize this Concpt
		1. Using Mnemonis
		2. Using Visual Appeal and then Asks you to add into the notes.
22. Keyoword Synoymer and Phraser with GIF
23. Example Based off Real World Eaxmples (With Real World Date. With Real World Demonstration)
24. Dedicated Screen Representing the Important Points, Lectures or Notes (Visual Representation of the Note System)
25. Explaining Why of a Point of a Particular Concept by Obviousness.
26. Everyday (Scrum Meeting, the AMA Session), Totally Live So that Students are on the Grounds
27. Cards like Youtube  (Re-Routing if you do not know particular thing), it amkes you memorise the prerequisite and you are again ready to launch. (Bridge Courses)
28. Prerequisite Test (So that we can deliver knowing something)
29. Time-Stamps and Transcript Synced to the Video
30. Every topic also contains the meta (Showing, when a Question was asked from this topic with Importance Level Indicator Showing how important it is), the weightage with an indicator.
31. Code-Chef Real World Problem Intigration.
32. Video Pane on one side and Linked Markdown Edtior on onw side.
33. Proof of Concept + Why + How much Importance it has.
34. Touch Copy only when Solving Questions (and trust me we have a lot of them)
35. Video Cuts prompts then the Website acts accordingly.
36. When the user go ahead of the curve and use example engine to trigger some investigative points the Computer Awards him for his Curiosity and also Explains the Concepts (iF possible for the given knowledge or flags it and reminds the user when) the user revists that topic.
37. Judge Engine Connected to Code-Chef and submit us the Configuration File.
38. When an Information is Thrown to the Learner, it reinforces, asks them to make cutom notes of and reminds of those concepts,
39. System itself knows how many topics, how many concpets, its importance and everything.
40. Interactables
41. Energy Bar (Maintains Equilibirum between Lecture and Practice Sessions).
42. Story Thematised (Based on the Inclination they have), Thematized Feedback and Icon Settings
43. Growth Specifier
44. Difficulty Enghancer (So that Students do not sync into other paths and follow whatever they like)
45. The above is an illusion, it just keeps them that things have become Slow, everyhting changes but we keep in mind the previouds histiry and progress and current goal to personalize content for out learners.
46. Essentail Features to Progress, Non-Essential Features for Best Approach (Integration and Turning Off)
47. Book Progress Complition (Confidence Booster)
48. Understands Taste by Type of Book you prefer for Reading.
49. Vim Key Bindings to the Whole Application
50. Lite Mode and Full Mode (Full Mode Only Allows)
51. Concept Wise
52. When Revisioning : Focus both on asking the user to identify what's wrong and what's right too
53. Focus on Completeting the Syllabus Once and then Trageting Multiple Revision Attempts.
54. Hints, Other Perks, Behind the Scenes and Power Ups and Boosts and Tokens for the Curious Ones and the Hard Workers and the Challengee is always fresh and new with every Lecture, Quiz and any other thing.
55. Always sow how many These types of tokens are available in advance
56. Student Grouping and its subject to avaiibilitym if your friends did join another group and you did not get the good group you may lag behind.
57. Your Group Score also is tied to your Overall Rating System that gives you advantage over a lot of other sytems, also the Computer Itself Randomizes so that the Initial Group Score is Fair.
58. If the Group wins show them why they did, how did they increase so much, also their failures and winings to motivate and to seem legit.
59. No Screenshot Taking System, only from the Command in the Frame linked with Point 9
60. In Between the Teacher is Presented when, he has to Show some complex, tippadi aur something
61. Give the Proof of Concept for Very Basic Things too, if you say Open Source, show them the Code and how to Access it.
62. Use of VisuAlgo and Alogrithm Visualier for Visulaization Purposes, also using SourceTail for Code Visualization
63. Manim Engine for Mathematical and Explantory Video Concepts
64. Make Platform Friendly Websites using Frameowrk for HTML, CSS and JS then make Backend using anything you wish.
65. Launch Mood Board First for Your Brand theme, design UI Components and other material.
66. Keep Base of Quizrr App by Mathong team, they have the Best Quizz Platform.
67. It Should Purely be a Game
68. Dark and Light Mode
69. Focused Towards Community Building and Engagement
70. Focus Towards Making Basic Computer Science and Mathematics Courses
71. Brilliant Like Interactables
72. Interactables using p5.js and H5P
73. Tagging at Each Element
74. ChatBot
	1. Error Code Resolution
	2. Understanding User Problem
75. Global Settings
	1. Theme
	2. Difficulty
	3. User Stack
	4. SFX
76. Editor with Learning Material
77. Using Google Text To Speech Hindi Support
78. Go For Material Design  (Google Supported), Assets are Available
79. Assets https://thenounproject.com/browse/collection-icon/science-and-technology-material-design-icons-12577/?p=1
80. Manim + Triggers + Lab
81. Follow Exactly the Google Guide on Building Material Theme Websites and Web Apps.
82. Open Source Books
83. Interactables
	1. What a book has to say
	2. Question Solver
	3. Visualizer
	4. Code
	5. Question and Answer
	6. Mystery Thoughts
84. Canvas Manager (Launches, Pushes, does all the dancing)
85. Content Managment System
86. Guiding Principles
	1. Eveyrthing Should be Open Source
	2. It Should be Free of Cost
	3. It should be feasible to made by you
	4. It Should allow automation
	5. It should purely be translated into a game center dynamic
	6. It should be scalable with code.
	7. It should add to the User Journey
	8. No Capex and Very Less Operational Cost
	9. Every Element of the Game should give meaninful results knowing the current state of the Player and the Game.
	10. User First Approach
	11. Building Feature Manager and then Building Integration and then Building Content Generator.
	12. The A.I gives whatever, it must classify the student into buckets (It Should Categorize First then Generate Content) (Classify then Act)
	13. The Pacing should be such that it must suit the player playing it (Pick Up the Cues from the Player)
	14. Deep Patterns with help of Branching and other highly complex structure.
	15. Community like Instagram but with lots of Block
87. It Should have a Progree Share Feature Outside of the app and inside of the app too, (Local Community, Global Community)
88. Not Too Much Fuss, Only Two Currency, One Spending Currency and the Other Premium Currency.
	1. Floating Point Currency
	2. Can Not be Bought on the Store, no minitransactions
89. Helps You
