1. QuestGen Engine
2. Exampler
3. Interactables
4. Therefore Learning Base Brand Theme and Components
5. Troubleshooter Engine
6. Player Stack
7. Practicer
8. First Code and then Refine the Art of the Website.
9. Google Hindi TTS
10. Latex Support
11. Take Physics Wallah as a Reference, Entirely Copy the System in the First Hand then make Gradual Changes.
12. Master Your Basic Learn Compo and fill it with Features.
13. Make Course Update Document (To Follow to Update Courses for Every Month)
14. Photo Step Diagram for every Concept Illustration
	1. Saves Time doing Illustrations
	2. Automated
	3. Fully Configurable.