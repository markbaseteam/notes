1. AR, VR Learning
2. Integration with Google Calendar
3. Integration with Other Learning Platforms