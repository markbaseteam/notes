+ Make a Portfolio Website using React


+ Showcase all your Projects sphere
+ Your Interest and Everthing
+ Link to Obsidian Notes.
+ Creating a 2D Game Engine
	+ https://www.youtube.com/watch?v=025QFeZfeyM
	+ https://www.amazon.in/Engine-Architecture-Third-Jason-Gregory/dp/1138035459
+ Make a Game Engine




+ Projects to Add
	+ Game Development
		+ Making your own game engine with JAVA
		+ Using Other Game Engine to make a Simple, Game like the First Tree.
	+ Coding
		+ Participating in Code Jams
		+ Making your own inventory management Software
		+ Learning Competetive Programming

	+ Academics
		+ Following up with IIT-JEE Syllabus
		+ Teaching class 9-12 Science and Computer Science
		
	+ Entrepreneurship
		+ Doing Small Tests and Collecting Ideas and then contributing to the bigger Repositories.
		+ Focusing on the Engine rather than the Content.
		+ Manim Engine
		+ H5P and Interactables
		+ Making Future Proof Knowledge Base