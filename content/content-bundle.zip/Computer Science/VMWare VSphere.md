---
type : Concept
subject : 
branch : 
chapter : 
---

> <mark class="hltr-blue">Link</mark> :
> <mark class="hltr-cyan">Tag</mark>  :

# VMWare VSphere
>[!lecpg] Lecture Slide for VMWare and VSphere
>![](https://i.imgur.com/iac0uOH.png)


>[!lecpg] Lecture Slide for VMWare Virtualization
>![](https://i.imgur.com/BEPKof9.png)

## 1. VCenter Server
>[!lecpg] Lecture Slide for VCenter Server
>![](https://i.imgur.com/A2XwRN3.png)

>[!lecpg] Lecture Slide for Above Concept
>![](https://i.imgur.com/CWO7sQU.png)
